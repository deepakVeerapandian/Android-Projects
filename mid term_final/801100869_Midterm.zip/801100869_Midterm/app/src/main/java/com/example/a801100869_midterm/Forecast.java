package com.example.a801100869_midterm;

public class Forecast {
    String temp,humidity,description,dt_txt,icon;

    public Forecast() {
    }
}
