package com.example.a801100869_midterm;

import java.io.Serializable;

public class Cities implements Serializable {
    String city_name,country_name;

    public Cities() {
    }
}
