package com.example.a801100869_midterm;

public class CurrentWeather {
    String temp,temp_min,temp_max,humidity,speed,description,icon;

    public CurrentWeather() {
    }
}
