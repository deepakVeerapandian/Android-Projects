package com.example.midtermprep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class DisplayActivity extends AppCompatActivity {
    ImageView img;
    TextView tv_txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        img = findViewById(R.id.imgDisplay);
        tv_txt = findViewById(R.id.txtDisplay);

        Music music = (Music) getIntent().getSerializableExtra(MusicAdapter.TAG_IMAGE);

        tv_txt.setText(music.trackName+"");
        Picasso.get().load(music.trackViewUrl).into(img);

    }
}
