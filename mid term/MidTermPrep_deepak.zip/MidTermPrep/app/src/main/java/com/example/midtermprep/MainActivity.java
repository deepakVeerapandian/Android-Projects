package com.example.midtermprep;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private EditText et_song;
    private TextView tv_limit;
    private SeekBar seekBar;
    private Button btn_search;
    private Button btn_reset;
    private Switch switch_sort;
    private RecyclerView rv_list;
    private ProgressDialog pd;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    ArrayList<Music> sourcesList;
    public static String sort = "date";
    int limit = 10;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("iTunes Music Search");

        et_song = findViewById(R.id.txtSong);
        tv_limit = findViewById(R.id.txtLimit);
        seekBar = findViewById(R.id.seekBar);
        btn_reset = findViewById(R.id.btnReset);
        btn_search = findViewById(R.id.btnSearch);
        rv_list = findViewById(R.id.recylerView);
        switch_sort = findViewById(R.id.switch1);
        pd = new ProgressDialog(MainActivity.this);

        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isConnected())
                {
                    String song = et_song.getText().toString();
                    if(!song.equals(""))
                    {
                        String Url = "https://itunes.apple.com/search?term=";
                        String [] songArray = song.split(" ");
                        Boolean flag = true;
                        String name = "";
                        for(String x : songArray)
                        {
                            if(flag) {
                                name = x;
                                flag = false;
                            }
                            else
                                name = name + "+" + x;
                        }
                        Url = Url + name + "&limit=" + limit;
                        new GetJSONParserAsync().execute(Url);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Enter a song", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btn_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBar.setProgress(10);
                tv_limit.setText("Limit : 10 ");
                et_song.setText("");
                switch_sort.setChecked(true);

                sourcesList = new ArrayList<Music>();
                setDetailsForList();
            }
        });

        seekBar.setMin(10);
        seekBar.setMax(30);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                seekBar.setProgress(progress);
                limit = seekBar.getProgress();
                tv_limit.setText("Limit: " + limit + "");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });

        switch_sort.setChecked(true);
        switch_sort.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    sort = "date";
                    Collections.sort(sourcesList, dateComparator);
                }
                else {
                    sort = "price";
                    Collections.sort(sourcesList, priceComparator);
                }
                setDetailsForList();
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            Toast.makeText(getApplicationContext(), "No Internet Connected", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public static Comparator<Music> dateComparator = new Comparator<Music>() {
        @Override
        public int compare(Music o1, Music o2) {
//                Date x = new Date(o2.getReleaseDate());
//                Date y = new Date(o1.getReleaseDate());
//                return x.compareTo(y);
            return o2.getReleaseDate().compareTo(o1.getReleaseDate());
        }
    };

    public static Comparator<Music> priceComparator = new Comparator<Music>() {
        @Override
        public int compare(Music o1, Music o2) {
                double x = Double.parseDouble(o2.getTrackPrice());
                double y = Double.parseDouble(o1.getTrackPrice());
                return (int) (x-y);
        }
    };

    public void setDetailsForList(){
        rv_list.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getBaseContext());
        rv_list.setLayoutManager(layoutManager);
        mAdapter = new MusicAdapter(sourcesList);
        rv_list.setAdapter(mAdapter);
    }

    private class GetJSONParserAsync extends AsyncTask<String, Void, ArrayList<Music>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            prg.setVisibility(View.VISIBLE);

            pd.setMessage("Loading Sources...");
            pd.show();
        }

        @Override
        protected void onPostExecute(ArrayList<Music> sources) {
            super.onPostExecute(sources);
            sourcesList = sources;

            setDetailsForList();

//            SourceAdapter adapter = new SourceAdapter(getBaseContext(),R.layout.music_list, sourcesList);
//            lv_sources.setAdapter(adapter);
            if(sources.size() == 0)
                Toast.makeText(MainActivity.this, "No source Found", Toast.LENGTH_SHORT).show();
//            prg.setVisibility(View.INVISIBLE);
            pd.dismiss();
        }

        @Override
        protected ArrayList<Music> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            ArrayList<Music> result = new ArrayList<>();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");
                    JSONObject root = new JSONObject(json);
                    JSONArray trackList = root.getJSONArray("results");

                    if(trackList.length() !=0) {

                        for (int i = 0; i < limit; i++) {
                            JSONObject track = trackList.getJSONObject(i);
                            Music source = new Music();
                            source.trackPrice = track.getString("trackPrice");
                            source.artistName = track.getString("artistName");
                            source.trackName = track.getString("trackName");
                            source.trackViewUrl = track.getString("trackViewUrl");
//                            source.releaseDate = track.getString("releaseDate");

                            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            try {
                                Date date = format.parse(track.getString("releaseDate"));
//                                String required_format  = (String) DateFormat.format("MM-dd-yyyy", date);
//                                source.releaseDate = required_format;

//                                Date required_format  = (Date) DateFormat.format("MM-dd-yyyy", date);
                                source.releaseDate = date;
//                                source.releaseDate = new Date(track.getString("releaseDate"));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            result.add(source);
                        }
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }
    }

}
