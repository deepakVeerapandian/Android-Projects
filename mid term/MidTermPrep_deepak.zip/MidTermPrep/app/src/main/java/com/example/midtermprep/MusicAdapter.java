package com.example.midtermprep;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.security.PublicKey;
import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> {
    ArrayList<Music> mData;
    public static String TAG_IMAGE = "TAG_IMAGE";
    public static String TAG_TEXT = "TAG_TEXT";

    public MusicAdapter(ArrayList<Music> mData) {
        this.mData = mData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.music_list, parent, false);
        ViewHolder viewholder = new ViewHolder(view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Music music = mData.get(position);
        holder.tv_Artist.setText(music.artistName);
        holder.tv_track.setText(music.trackName);
        holder.tv_price.setText(music.trackPrice+" $");
        holder.tv_date.setText(music.releaseDate+"");

        holder.music = music;

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public  static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_Artist;
        TextView tv_track;
        TextView tv_price;
        TextView tv_date;
        Music music;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            this.music = music;
            tv_Artist = itemView.findViewById(R.id.txtArtistNameValue);
            tv_track = itemView.findViewById(R.id.txtTrackNameValue);
            tv_price = itemView.findViewById(R.id.txtPriceValue);
            tv_date = itemView.findViewById(R.id.txtDateValue);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(itemView.getContext(),DisplayActivity.class);
                    intent.putExtra(TAG_IMAGE, music);
//                    intent.putExtra(TAG_TEXT, music.artistName);
                    itemView.getContext().startActivity(intent);
                }
            });

        }
    }
}
