package com.example.midtermprep;

import java.io.Serializable;
import java.util.Date;

public class Music implements Serializable {
    String trackName,artistName,trackPrice,trackViewUrl;
    Date releaseDate;

    public Music() {
    }

    public String getTrackPrice() {
        return trackPrice;
    }

    public void setTrackPrice(String trackPrice) {
        this.trackPrice = trackPrice;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }
}
