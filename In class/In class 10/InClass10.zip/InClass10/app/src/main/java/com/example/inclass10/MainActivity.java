package com.example.inclass10;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        Map<String , Object> userMap = new HashMap<>();
//        userMap.put("name", "deepak");
//        userMap.put("age", 25);
//        db.collection("users").add(userMap);
//        db.collection("users").document("user1").set(userMap);

        User user = new User("ram", 24);
        Map<String , Object> userMap = user.toHashMap();

        db.collection("users").document("user2")
                .set(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){

                }
                else{
                    Log.d("demo", task.getException().toString());
                }
            }
        });

//        db.collection("users").addSnapshotListener(new EventListener<QuerySnapshot>() {
//            @Override
//            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
//                for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots){
//                    Log.d("demo..", documentSnapshot.getData().toString());
//                    User user = new User(documentSnapshot.getData());
//                    Log.d("demo return ",user.toString());
//                }
//            }
//        });

        User user1 = new User("ram11", 4);
        User user2 = new User("ram22", 14);
        User user3 = new User("ram33", 74);

        ArrayList<User> usersList = new ArrayList<>();
        usersList.add(user1);
        usersList.add(user2);
        usersList.add(user3);

        db.collection("users").orderBy("age").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){
                            for(QueryDocumentSnapshot queryDocumentSnapshot : task.getResult())
                                Log.d("demo query : ", queryDocumentSnapshot.getData().toString());
                        }
                        else{
                            Log.d("demo", task.getException().toString());
                        }
                    }
                });

    }
}
