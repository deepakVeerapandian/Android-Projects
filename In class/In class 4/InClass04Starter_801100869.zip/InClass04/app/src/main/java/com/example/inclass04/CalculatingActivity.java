package com.example.inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatingActivity extends AppCompatActivity {
    public static String TAG_RESULT = "TAG_RESULT";
    private EditText et_num1;
    private EditText et_num2;
    private Button btn_calculate;
    private TextView tv_heading;
    String title = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculating);
        setTitle("Calculating Activity");

        et_num1 = findViewById(R.id.editTextNum1);
        et_num2 = findViewById(R.id.editTextNum2);
        btn_calculate = findViewById(R.id.btncalculate);
        tv_heading = findViewById(R.id.txtHeading);

        title = getIntent().getExtras().getString(MainActivity.TAG_operation);
        tv_heading.setText(title);

        btn_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double num1 = Double.parseDouble(et_num1.getText().toString());
                double num2 = Double.parseDouble(et_num2.getText().toString());
                double result = 0.0;
//                String action = getIntent().getExtras().getString(MainActivity.TAG_operation);
                if(title.equals("Adding")){
                    result = num1 + num2;
                }
                else
                    result = num1 - num2;

                Intent intent = new Intent();
                intent.putExtra(TAG_RESULT,result);
                setResult(RESULT_OK,intent);
                finish();
            }

        });


    }
}
