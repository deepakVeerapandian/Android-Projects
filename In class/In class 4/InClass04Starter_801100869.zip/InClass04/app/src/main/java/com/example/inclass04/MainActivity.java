package com.example.inclass04;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btn_add;
    private Button btn_subtract;
    private TextView tv_result;
    public static String TAG_operation = "TAG_operation";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");

        btn_add = findViewById(R.id.btnAdd);
        btn_subtract = findViewById(R.id.btnSubtract);
        tv_result = findViewById(R.id.valueResult);

        tv_result.setVisibility(View.INVISIBLE);

        final Intent intent = new Intent(MainActivity.this, CalculatingActivity.class);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra(TAG_operation, "Adding");
                startActivityForResult(intent,100);
            }
        });

        btn_subtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra(TAG_operation, "Subtracting");
                startActivityForResult(intent,100);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == 100 && resultCode == RESULT_OK){
            double result = data.getExtras().getDouble(CalculatingActivity.TAG_RESULT);
            tv_result.setVisibility(View.VISIBLE);
            tv_result.setText(result+"");
        }
    }
}
