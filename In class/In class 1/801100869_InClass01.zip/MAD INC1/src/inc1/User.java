package inc1;

public class User {
	
	String firstname;
	String lastname;
	int age;
	String email;
	String gender;
	String city;
	String state;
	
	public User(String firstname, String lastname, int age,String email, String gender, String city, String state){
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
		this.email  = email;
		this.gender = gender;  
		this.city = city;
		this.state = state;
	}
	
	@Override
	public String toString() {
		return ("Users === firstname : "+this.firstname+" ,lastname : "+this.lastname + " ,age : "+this.age + " ,email : "+this.email + 
				" ,gender : "+this.gender+" ,city : "+this.city + " ,state : "+this.state);
	}

}
