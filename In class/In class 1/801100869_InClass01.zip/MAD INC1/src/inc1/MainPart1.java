package inc1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainPart1 
{
	public static void main(String[] args)
	{
		ArrayList<User> userList = new ArrayList<>();
		for(String users : Data.users)
		{			
			String [] elements = users.split(",");
			String firstname = elements[0].trim();
			String lastname = elements[1].trim();
			int age = Integer.parseInt(elements[2]);
			String email = elements[3].trim();
			String gender = elements[4].trim();
			String city = elements[5].trim();
			String state = elements[6].trim();
			User user = new User(firstname,lastname,age,email,gender,city,state);
			userList.add(user);
		}
		
		Collections.sort(userList, userAge);
		
		for(int i=0; i<10; i++)
			System.out.println(userList.get(i).toString());
	}
	
	public static Comparator<User> userAge = new Comparator<User>()
	{
		public int compare(User x1, User x2)
		{
			return x2.age-x1.age;
		}
	};
	
}
