package inc1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MainPart2 {
	public static void main(String[] args)
	{
		HashMap <String, Integer> statesHashMap = new HashMap<>(); 
		for(String users : Data.users)
		{			
			String [] elements = users.split(",");
			String state = elements[6].trim();
			int count = 1;
			
			if(statesHashMap.containsKey(state))
			{
				count = statesHashMap.get(state);
				count++;
			}			
			statesHashMap.put(state, count);
		}	
		
	  Set<Entry<String, Integer>> entrySet = statesHashMap.entrySet();
	  List<Entry<String, Integer>> stateList = new ArrayList<Entry<String, Integer>>(entrySet);
	  Collections.sort(stateList, new SortByValue());
	  System.out.println("States"+"  Count");
	  
	  for(Map.Entry<String, Integer> entry : stateList)
	         System.out.println(entry.getKey()+"      "+entry.getValue()+"  ");
	}
	
}
class SortByValue implements Comparator<Map.Entry<String, Integer>>
{
	@Override
    public int compare( Map.Entry<String,Integer> entry1, Map.Entry<String,Integer> entry2){
        return (entry1.getValue()).compareTo( entry2.getValue() );
    }
}
