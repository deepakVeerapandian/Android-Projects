package com.example.inclass11;

public class Image {
    String imageUrl, imagePath;
}
