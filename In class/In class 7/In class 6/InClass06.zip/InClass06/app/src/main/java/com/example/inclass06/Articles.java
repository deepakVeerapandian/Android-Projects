package com.example.inclass06;

public class Articles {
    String title;
    String date;
    String imageURL;
    String description;

    public Articles() {
    }
}
