package com.example.recyclerview;

public class Songs {
    String trackName;
    String albumName;
    String artistName;
    String updatedTime;
    String trackshareURL;

    public Songs() {
    }
}