package com.example.inclass05;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class GetImageURLAsync extends AsyncTask<String, Void, String> {
    ImageView imgView;
    ImageView nextImgBtn;
    ImageView prevImgBtn;
    Bitmap bitmap = null;
    int page = 0;


    public GetImageURLAsync(ImageView img, ImageView nextBtn,ImageView prevBtn) {
        imgView = img;
        nextImgBtn = nextBtn;
        prevImgBtn = prevBtn;
//        Page = page;
    }

    @Override
    protected String doInBackground(String... strings) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String result = null;
        try {
            URL url = new URL("http://dev.theappsdr.com/apis/photos/index.php?keyword=" + strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line + ";");
                }
                result = stringBuilder.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(String imageUrl) {
        super.onPostExecute(imageUrl);
        final String[] urls = imageUrl.split(";");
        new GetImageAsync(imgView).execute(urls[0]);

        nextImgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(page < urls.length-1 )
                    page = page + 1;
                else
                    page = 0;
//                if(page > urls.length)
//                    page = 0;
//                else
//                    page = page + 1;

                new GetImageAsync(imgView).execute(urls[page]);

            }
        });

        prevImgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(page > 0)
                    page = page - 1;
                else
                    page = urls.length-1;
                new GetImageAsync(imgView).execute(urls[page]);

            }
        });
    }
}