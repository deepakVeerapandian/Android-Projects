package com.example.inclass09;

public class User {
    String fname,lname;
    int id;

    @Override
    public String toString() {
        return fname + " " + lname;
    }
}
