//Deepak Veerapandian 801100869, Rishi Kumar Gnanasundaram 801101490
package com.example.homework05;

public class News {
    String author;
    String title;
    String url;
    String urlToImage;
    String publishedAt;

    public News() {
    }
}
