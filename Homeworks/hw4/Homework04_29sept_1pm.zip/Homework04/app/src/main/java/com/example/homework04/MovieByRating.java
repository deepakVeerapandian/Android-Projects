package com.example.homework04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MovieByRating extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_by_rating);
    }
}
