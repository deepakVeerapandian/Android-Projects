//Deepak Veerapandian 801100869, Rishi Kumar Gnanasundaram 801101490
package com.example.homework04;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private Button btn_addMovie;
    private Button btn_edit;
    private Button btn_deleteMovie;
    private Button btn_listByYear;
    private Button btn_listByRating;

    public ArrayList<Movie> movieList = new ArrayList<>();
    public String [] movieArray = {};
    public String action = "";
    public int movieEditIndex = -1;
    public static String TAG_MOVIELIST = "TAG_MOVIELIST";
    public static String TAG_SELECTEDMOVIE = "TAG_SELECTEDMOVIE";
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Favourite Movies");

        btn_addMovie = findViewById(R.id.btnAddMovie);
        btn_edit = findViewById(R.id.btnEdit);
        btn_deleteMovie = findViewById(R.id.btnDeleteMovie);
        btn_listByYear = findViewById(R.id.btnListByYear);
        btn_listByRating = findViewById(R.id.btnListByRating);

        builder = new AlertDialog.Builder(this);
        showMoviesAlertDialog("");

        btn_addMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action = "add";
                Intent intentAdd = new Intent(MainActivity.this, AddMovieActivity.class);
                startActivityForResult(intentAdd, 1);
            }
        });

        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action = "edit";
                AlertDialog moviesAlert = builder.create();
                moviesAlert.show();
                showMoviesAlertDialog(action);
            }
        });

        btn_deleteMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action = "delete";
                AlertDialog moviesAlert = builder.create();
                moviesAlert.show();
                showMoviesAlertDialog(action);
            }
        });

        btn_listByYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.homework04.intent.action.YEAR");
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.putExtra(TAG_MOVIELIST, movieList);
                if(!movieList.isEmpty())
                    startActivity(intent);
                else
                    Toast.makeText(getApplicationContext(), "No movie to display", Toast.LENGTH_SHORT).show();
            }
        });

        btn_listByRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.homework04.intent.action.RATING");
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.putExtra(TAG_MOVIELIST, movieList);
                if(!movieList.isEmpty())
                    startActivity(intent);
                else
                    Toast.makeText(getApplicationContext(), "No movie to display", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /******ADD MOVIE******/
        if(requestCode == 1 && resultCode == RESULT_OK){
            Movie movie = (Movie) data.getExtras().getSerializable(AddMovieActivity.TAG_MOVIE);
            movieList.add(movie);
            movieArray = new String[movieList.size()];
            int i = 0;
            for(Movie x : movieList){
                movieArray[i] = x.getMovieName();
                i++;
            }
            showMoviesAlertDialog("");
        }

        /******EDIT MOVIE******/
        if(requestCode == 2 && resultCode == RESULT_OK) {
            Movie editedMovie = (Movie) data.getExtras().getSerializable(EditMovieActivity.TAG_EDIT_MOVIE);
            movieList.set(movieEditIndex, editedMovie);
            movieArray[movieEditIndex] = editedMovie.getMovieName();
            showMoviesAlertDialog("");
        }
    }

    public void showMoviesAlertDialog(final String action){
        builder.setTitle("Pick a Movie")
                .setCancelable(true)
                .setItems(movieArray, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Movie selectedMovie = movieList.get(which);
                         switch (action){
                            case "edit":
                                Intent intentEdit = new Intent(MainActivity.this, EditMovieActivity.class);
                                intentEdit.putExtra(TAG_SELECTEDMOVIE,selectedMovie);
                                movieEditIndex = which;
                                startActivityForResult(intentEdit, 2);
                                break;
                            case "delete":
                                deleteMovie(which);
                                break;
                            default:
                                break;
                        }
                    }
                });
    }

    public void deleteMovie(int movieDeleteIndex){
        String deletedMovie = movieList.get(movieDeleteIndex).getMovieName();
        Toast.makeText(this, deletedMovie + " was deleted", Toast.LENGTH_SHORT).show();
        movieList.remove(movieDeleteIndex);
        movieArray = new String[movieList.size()];
        int i = 0;
        for(Movie x : movieList){
            movieArray[i] = x.getMovieName();
            i++;
        }
        showMoviesAlertDialog("");
    }
}
