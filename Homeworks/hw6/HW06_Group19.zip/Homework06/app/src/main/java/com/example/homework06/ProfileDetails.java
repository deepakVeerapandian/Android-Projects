package com.example.homework06;

import java.io.Serializable;

public class ProfileDetails implements Serializable {

    String firstName;
    String lastName;
    String studentId;
    String department;
    int imageId;
}